import { motion } from "framer-motion";

export default function Hero(){
  return (
    <section className="text-center py-20">
      <motion.h1 initial={{opacity:0,y:40}} animate={{opacity:1,y:0}} transition={{duration:0.6}}
        className="text-5xl font-bold">
        Build Your Digital Presence
      </motion.h1>

      <motion.p initial={{opacity:0}} animate={{opacity:1}} transition={{delay:0.3}}
        className="mt-4 text-gray-600 dark:text-gray-300 max-w-xl mx-auto">
        We help companies grow with modern websites, brand strategy, and digital marketing.
      </motion.p>

      <motion.button initial={{opacity:0}} animate={{opacity:1}} transition={{delay:0.5}}
        className="mt-6 px-6 py-3 bg-blue-600 text-white rounded hover:bg-blue-700">
        Get Started
      </motion.button>
    </section>
  );
}