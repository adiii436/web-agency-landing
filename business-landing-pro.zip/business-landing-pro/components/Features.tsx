import { motion } from "framer-motion";

export default function Features(){
  return (
    <section className="py-16 bg-gray-100 dark:bg-gray-900 text-center">
      <h2 className="text-3xl font-bold">Our Services</h2>
      <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-6 mx-6">
        {["Web Development","Digital Marketing","Brand Strategy"].map((service,i)=>(
          <motion.div key={i} initial={{opacity:0,y:40}} whileInView={{opacity:1,y:0}}
            viewport={{once:true}} transition={{duration:0.4,delay:i*0.2}}
            className="p-6 bg-white dark:bg-gray-800 shadow rounded">
            {service}
          </motion.div>
        ))}
      </div>
    </section>
  );
}