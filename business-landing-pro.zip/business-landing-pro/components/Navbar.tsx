"use client";
import { useState, useEffect } from "react";

export default function Navbar(){
  const [dark,setDark]=useState(false);
  useEffect(()=>{document.documentElement.classList.toggle("dark",dark)},[dark]);

  return (
    <nav className="p-4 shadow flex justify-between items-center">
      <h1 className="font-bold text-xl">Web Agency Pro</h1>
      <ul className="flex gap-6">
        <li><a href="/">Home</a></li>
        <li><a href="/services">Services</a></li>
        <li><a href="/portfolio">Portfolio</a></li>
        <li><a href="/about">About</a></li>
        <li><a href="/contact">Contact</a></li>
      </ul>
      <button onClick={()=>setDark(!dark)} className="px-3 py-1 border rounded">
        {dark?"Light":"Dark"}
      </button>
    </nav>
  );
}