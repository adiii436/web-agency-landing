export default function Contact(){
  return (
    <div className='p-10'>
      <h1 className='text-3xl font-bold'>Contact Us</h1>
      <form action='/api/contact' method='POST' className='mt-6 grid gap-4 max-w-md'>
        <input name='name' className='p-2 border rounded' placeholder='Your Name' />
        <input name='email' className='p-2 border rounded' placeholder='Your Email' />
        <textarea name='message' className='p-2 border rounded' placeholder='Your Message'></textarea>
        <button className='px-4 py-2 bg-blue-600 text-white rounded'>Send</button>
      </form>
    </div>
  );
}