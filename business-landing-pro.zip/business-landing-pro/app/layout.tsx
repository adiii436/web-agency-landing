export const metadata={title:"Business Landing Pro"};
import './globals.css';
export default function RootLayout({children}:{children:React.ReactNode}){
  return (
    <html lang="en">
      <body className="bg-white dark:bg-black text-black dark:text-white transition-all">{children}</body>
    </html>
  );
}