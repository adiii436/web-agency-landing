export async function POST(req:Request){
  const data = await req.formData();
  console.log("Contact form:", Object.fromEntries(data));
  return Response.json({success:true});
}